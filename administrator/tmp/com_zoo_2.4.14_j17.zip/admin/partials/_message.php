<div class="no-content-message">

	<?php if ($title) : ?>
	<h1><?php echo $title; ?></h1>
	<?php endif; ?>
	
	<?php if ($message) : ?>
	<p><?php echo $message; ?></p>
	<?php endif; ?>

</div>