<?php
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<td colspan="5">
		<?php echo $this->pagination->getListFooter(); ?>
		<br/><br/>
		<div align="center">
			&copy;&nbsp;&nbsp;2011 <a href="http://g4j.laoneo.net" target="_blank">allon moritz</a>
		</div>
	</td>
</tr>