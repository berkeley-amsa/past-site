<?php
/**
 * CHANGELOG
 * 
 * This is the changelog for mod_pctechfilebasereader.<br>
 * <b>Please</b> be patient =;)
 * @subpackage Documentation
 * @version 	1.7
 * @package    mod_pctechfilebasereader
 * @author     pcte.ch
 * @Copyright Copyright (C) 2010 pcte.ch Webservices
 * @license 	GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */


//--No direct access to this changelog...
defined('_JEXEC') or die('=;)');

//--For phpDocumentor documentation we need to construct a function ;)
/**
 * CHANGELOG
 * {@source}
 */
function CHANGELOG()
{
/*
_______________________________________________
_______________________________________________

This is the changelog for mod_pctechfilebasereader

Please be patient =;)
_______________________________________________
_______________________________________________

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note
______________________________________________

20.12.2010 Update from Version for J1.5
 ! Startup
+ -> Installer.XML file set to 1.6 style
01.01.20111 pcte.ch
+ -> German Language and English Language Set to 1.6 Style
^ -> adding GPL Licence Informations
31.07.2011 
+ -> Adding Joomla 1.7 compatibility
+ -> Installer.XML file set to 1.7 style
*/
}//--This is the END