NOTES
------------
This Program is released under the GNU/PL-license.
Be sure to read the LICENSE.txt and INSTALL.txt files!