<?php

/**
* @version		1.2
* @copyright	Copyright (C) 2010-2011 Anders Wasén
* @license		GNU/GPL
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

abstract class JFormFieldMySettings extends JFormField {
 
        protected $type = 'MySettings'; 
		
}



?>