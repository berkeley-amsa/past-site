<?php
/*======================================================================*\
|| #################################################################### ||
|| # Youjoomla LLC - YJ- Licence Number #license_no#
|| # Licensed to - #license_name#
|| # Package - YJ Piecemaker                                            ||
|| # Copyright (C) 2010  Youjoomla LLC. All Rights Reserved.            ||
|| # license - PHP files are licensed under  GNU/GPL V2                 ||
|| # license - CSS  - JS - IMAGE files  are Copyrighted material        ||
|| # bound by Proprietary License of Youjoomla LLC                      ||
|| # for more information visit http://www.youjoomla.com/license.html   ||
|| # Redistribution and  modification of this software                  ||
|| # is bounded by its licenses                                         ||
|| # websites - http://www.youjoomla.com | http://www.yjsimplegrid.com  ||
|| #################################################################### ||
\*======================================================================*/
/*

THIS IS YOUR NEW MODULE TEMPLATE 
THERE ARE SEVERAL HOOKS YOU CAN USE TO MAKE OWN MODULE LAYOUT
TO UNDERSTAND THE MODULE HOOKS AND AVAILABLE VARIABLES PLEASE OPEN modules/mod_yj_piecemaker/tmpl/Default/default.php
AND CHECK THE COMMENTS
*/
// no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<!-- http://www.Youjoomla.com  Youjoomla YJ Piecemaker  Module for Joomla 1.5 starts here -->
<div style="text-align:center;">
<strong>To create your custom module layout please go to modules/mod_yj_piecemaker/tmpl/New/default.php</strong>
</div>

