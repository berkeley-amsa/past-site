<?php
/**
* @package   ZOO Comment
* @file      changelog.php
* @version   2.4.2
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) 2007 - 2011 YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

?>

Changelog
------------

2.4.2
# fixed space for for floated media elements (display: block)

2.4.1
# fixed bug with storing params in J1.6

2.4.0
^ changes to underlying framework

2.3.1
# fixed matchheight function

2.3.0
^ migration to jQuery

2.1.0
- removed call to facebook REST lib

2.0.2
^ changes to building item links

2.0.1
# fixed bug with facebook avatars while not on zoo page

2.0.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note